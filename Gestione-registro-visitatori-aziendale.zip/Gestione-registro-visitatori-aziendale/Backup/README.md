# Gestione-registro-visitatori-aziendale

La soluzione di gestione registro visitatori aziendale ha lo scopo di risolvere una tematica normalmente scoperta in un’organizzazione o, piuttosto, gestita tramite procedure manuali, che spesso alimentano complessità organizzative nel controllo delle informazioni, privacy e sicurezza. 

PER MAGGIORI INFO, SCARICA LA DOCUMENTAZIONE:
[Readme - Gestione visitatori aziendale.pdf](https://github.com/Jamio-openwork/Gestione-registro-visitatori-aziendale/files/7196286/Readme.-.Gestione.visitatori.aziendale.pdf)


![Immagine 15](https://user-images.githubusercontent.com/86653778/134015905-4677d6a0-4283-474e-a6d6-71c7c5b49eae.png)
